<?php
// index.php
include 'cabecera.html';
?>